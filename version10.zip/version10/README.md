配置说明：
{
pip install pipenv
pip install -r requirments.txt
pip install django[argon2]
pip install mysqlclient
pipenv shell
pipenv install
cd Exam
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver

我的电脑的数据库用户名是root，密码是password，要在setting中改成自己的。
}


合并的说明：
{
没有添加app直接在原来代码上改的。
student这部分只有我一个人动，所以直接合并student就好。
但是！由于查看试卷和查看分数两部分在question这个app中，所以question也改了一部分代码。
（幸好只改了html，没有改python）
以下是修改的html：
mainexamstudent.html
previousstudent.html
}