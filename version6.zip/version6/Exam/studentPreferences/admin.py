from django.contrib import admin
from .models import StudentPreferenceModel
# Register your models here.
# admin.site.register(StudentPreferenceModel)