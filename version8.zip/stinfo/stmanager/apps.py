from django.apps import AppConfig


class StmanagerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'stmanager'
